\copy ratings_training FROM 'data/ratings_ml_training_dataset.csv' DELIMITER ',' CSV HEADER;
